using System;

public enum FoodTypes
{
    Wheat,
    Rice,
    Barley,
}
