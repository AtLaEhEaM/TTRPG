using UnityEngine;

[System.Serializable]
public class LoadFoodData
{
    public FoodTypes foodType;
    public int amount;
    public float remainingTime;
}